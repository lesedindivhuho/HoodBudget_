@Composable
fun AnalyticsScreen(
    viewModel: BudgetViewModel
){
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text="Analytics",
            style= MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("Spending Trend")
        Spacer(modifier = Modifier.height(250.dp))
        Text("Category Breakdown")
        Spacer(modifier = Modifier.height(250.dp))
    }
}
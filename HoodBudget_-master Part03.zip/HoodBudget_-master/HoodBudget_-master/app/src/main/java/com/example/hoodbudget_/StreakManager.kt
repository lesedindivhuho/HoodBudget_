package com.example.hoodbudget_

import android.content.Context
import java.time.LocalDate

object StreakManager {
    fun updateStreak(context: Context): Int {
        val prefs = context.getSharedPreferences(
            "streak_prefs",
            Context.MODE_PRIVATE
        )
        val today = LocalDate.now()
        val lastLoginString = prefs.getString("last_login", null)

        var streak = prefs.getInt("streak", 0)
        if (lastLoginString == null) {
            streak = 1
        } else {
            val lastLogin = LocalDate.parse(lastLoginString)
            when {
                lastLogin == today.minusDays(1) -> streak++
                lastLogin != today -> streak = 1
            }
        }
        prefs.edit()
            .putString("last_login", today.toString())
            .putInt("streak", streak)
            .apply()

        return streak
    }
}